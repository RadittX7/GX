import os
print("""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
 / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[37m| |_| |>  <   | || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ |___|_| |_|_|   |_|_| |_|___|\__|\__, |
                                              |___/
""")

print("""\33[0;32m[1] RUN\n[2] CANCEL\nWhich One Do You Use?""")

c = input(">>>: ")
if c == "1":
    os.system("apt install nodejs")
    os.system("rm -r GX.zip")
    os.system("rm -rf node_modules")
    os.system("unzip node_modules.zip")
    os.system("rm -rf node_modules.zip")
    os.system("rm -rf resources")
    os.system("unzip resources.zip")
    os.system("rm -rf resources.zip")
    os.system("rm -rf L4")
    os.system("unzip L4.zip")
    os.system("rm -rf L4.zip")
    os.system("bash install.sh")
    os.system("cd")
    os.system("cd GX")
    os.system("chmod +x *")
    os.system("cd")
    os.system("cd GX")
    os.system("cd node_modules && chmod +x GX")
    os.system("cd")
    os.system("cd GX")
    os.system("cd resources && chmod +x *")
    os.system("cd")
    os.system("cd GX")
    os.system("cd L4 && chmod +x *")
    os.system("cd")
    os.system("cd GX")
    os.system("pip install colorama")
    os.system("npm install user-agents")
    os.system("python3 x.py")

elif c == "2":
    os.system("clear")

print("\33[0;32m[ √ ] S U C C E S S F U L L Y")
