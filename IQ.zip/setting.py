import os
print("""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
 / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[37m| |_| |>  <   | || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ |___|_| |_|_|   |_|_| |_|___|\__|\__, |
                                              |___/
\033[0;91m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣠⠒⠀⠀⠀⡴⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣶⠞⠋⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢰⠁⠀⠀⠀⢰⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⡟⠀⠀⠀⠀⣿⠂⠀⠀⠀⠀⣀⠄⡴⢈⣤⣎⠴⡏⠀⣀⠄⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢸⣧⠀⠀⠀⠀⣿⠃⠀⠀⠀⡞⠀⣼⣽⣷⡿⡣⣾⣿⣶⣿⣶⡶⠖⠄⠂⠀⠀⠀
⠀⠀⢠⠀⢸⣿⠀⠀⠀⢀⢹⣆⢀⣀⠀⣆⣾⣻⢞⡿⣺⣿⡿⠿⠛⠛⠻⢿⣿⣶⣄⠀⠀⠀
⠀⠀⣯⠀⠘⣼⢢⣰⣇⣼⣾⣯⢹⢿⣶⣿⡿⣱⣿⡥⠃⣁⠤⣤⡤⡀⠀⠀⠈⣿⠏⠀⠀⠀
⠀⠀⠸⣧⡀⣹⣬⢿⡟⢿⢿⠿⣿⢻⡅⣾⣾⣏⡎⡴⠊⣀⠀⢈⣿⣾⠂⠀⢰⠿⠀⠀⠀⠀
⠀⠀⠀⠙⢿⣺⡜⢸⣿⣿⢘⡶⢵⣿⡿⣸⢿⣷⣞⣗⣺⣟⣿⠯⡶⠊⠀⣠⣣⠃⠀⠀⠀⠀
⠀⠀⠀⠐⠦⢛⠿⣾⣿⣛⣾⣶⣿⢿⣿⡛⣯⣽⣻⣿⡟⢿⣳⠟⠁⢀⣞⡕⠁⠀⠀⠀⠀⠀
⠀⠀⢠⠀⠀⡀⠳⣾⣿⣿⡿⣿⣷⣽⣯⣶⠾⢿⣿⣽⠼⠊⠀⢀⣴⡿⠽⠩⣇⣄⠀⠀⠀⠀
⠀⠀⢠⣷⣸⣿⣇⡈⣿⣿⣿⣿⣿⣻⣞⣿⠟⠋⠉⠙⠀⢀⣴⢹⣿⣷⢿⣛⡏⠉⠀⠀⠀⠀
⠀⠀⣾⣯⠛⠸⣞⣻⣯⢽⣴⣿⡟⣿⢹⡏⠀⢀⣤⠀⣴⣻⢿⣿⣿⡋⢤⠗⠀⠀⠀⠀⠀⠀
⢀⡀⠘⣿⡷⠋⠀⠻⢼⣟⠟⠃⢹⣿⣿⠀⢸⡿⠃⣾⣿⣿⢸⢽⣿⠛⠉⠀⡀⣤⡤⠂⠀⠀
⠸⣙⠤⡞⠀⠀⠀⡠⠔⠒⠂⢤⡘⠙⣻⠀⠘⣷⢰⢿⣟⣺⣟⣊⠉⢠⠤⣾⠞⡽⠧⢤⣀⡀
⠀⡯⣦⠁⠀⠀⣾⠀⠀⠀⠀⠀⣈⣲⣾⠀⠀⠈⠺⡾⣍⣫⠙⡳⣷⣏⠞⠉⠁⠈⠑⡽⡆⠀
⠀⠹⣦⡀⠀⠀⡿⣦⣄⣠⣴⠟⠉⠀⠈⡄⠀⠀⠀⠙⠮⣏⣙⠿⠓⠁⠀⠀⢀⣀⣀⣷⡇⠀
⠀⠀⠙⣧⡀⠀⠘⠾⠾⠼⠋⠀⠀⠀⠀⣸⣆⡀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠞⠃⠀⠐⣱⠁⠀
⠀⠀⠀⠀⠑⢄⠀⠀⠀⠀⠀⠀⠀⣠⠞⢿⢿⡟⠢⠤⣀⣀⣀⣀⣤⣚⣶⠤⣤⡤⠚⠁⠀⠀
⠀⠀⠀⠠⢔⣲⠿⠗⢲⣴⢶⣚⡩⠄⣱⡼⣮⡇⠀⠀⣀⠬⢻⢗⣟⣿⣵⠶⣳⠾⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠘⠢⠜⠋⢺⠏⠐⠪⠭⣙⣭⣟⡿⠷⣊⡱⢠⢾⡞⠚⠉⠛⠉⠁⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠃⠀⠀⠀⣔⢓⣒⣉⠩⣭⣟⠋⣿⣏⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣏⠋⡿⠚⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
""")

print("""\33[0;32m[1] RUN\n[2] CANCEL\nWhich One Do You Use?""")

c = input(">>>: ")
if c == "1":
    os.system("rm -rf IQ.zip")
    os.system("apt install python")
    os.system("apt install pip")
    os.system("apt install npm")
    os.system("rm -rf node_modules")
    os.system("unzip node_modules.zip")
    os.system("rm -rf node_modules.zip")
    os.system("rm -rf resources")
    os.system("unzip resources.zip")
    os.system("rm -rf resources.zip")
    os.system("rm -rf L4")
    os.system("unzip L4.zip")
    os.system("rm -rf L4.zip")
    os.system("rm -rf L7")
    os.system("unzip L7.zip")
    os.system("rm -rf L7.zip")
    os.system("bash install.sh")
    os.system("cd")
    os.system("cd GX")
    os.system("chmod +x *")
    os.system("cd")
    os.system("cd GX")
    os.system("cd node_modules && chmod +x *")
    os.system("cd")
    os.system("cd GX")
    os.system("cd resources && chmod +x *")
    os.system("cd")
    os.system("cd GX")
    os.system("cd L4 && chmod +x *")
    os.system("cd")
    os.system("cd GX")
    os.system("cd L7 && chmod +x *")
    os.system("cd")
    os.system("cd GX")
    os.system("pip install colorama")
    os.system("npm install user-agents")
    os.system("pip install -r requirements.txt")
    os.system("pip install cloudscraper")
    os.system("pip install socks")
    os.system("pip install pysocks")
    os.system("pip install colorama")
    os.system("pip install httpx")
    os.system("pip install undetected_chromedriver")
    os.system("pip install fake_headers")
    os.system("pip3 install cloudscraper")
    os.system("pip3 install socks")
    os.system("pip3 install pysocks")
    os.system("pip3 install colorama")
    os.system("pip3 install undetected_chromedriver")
    os.system("pip3 install httpx")
    os.system("pip3 install proxify")
    os.system("npm install fake-useragent")
    os.system("npm i cloudflare-bypasser")
    os.system("npm i axios")
    os.system("npm i cloudscraper")
    os.system("npm i crypto")
    os.system("npm i cluster")
    os.system("npm i user-agents")
    os.system("npm i user-agent")
    os.system("npm i tls")
    os.system("npm i set-cookie-parser")
    os.system("npm i requests")
    os.system("npm i request")
    os.system("npm i randomstring")
    os.system("npm i random-words")
    os.system("npm i random-useragent")
    os.system("npm i playwright")
    os.system("npm i net")
    os.system("npm i https")
    os.system("npm i http2")
    os.system("npm i http")
    os.system("npm i header-generator")
    os.system("npm i axios")
    os.system("npm i hcaptcha-solver")
    os.system("npm i gradient-string")
    os.system("npm i fs")
    os.system("npm i events")
    os.system("npm i crypto-random-string")
    os.system("npm i puppeteer")
    os.system("npm i puppeteer-extra")
    os.system("npm i puppeteer-extra-plugin-stealth")
    os.system("apt install graphviz")
    os.system("apt install samba-common-bin")
    os.system("apt install nodejs")
    os.system("python3 x.py")

elif c == "2":
    os.system("clear")

print("\33[0;32m[ √ ]PENGINSTALAN MODUL DI BATALKAN                                                                                                             ⚠️JIKA MODUL ZIP SUDAH JADI FOLDER JANGAN PERNAH INSTALL LAGI JIKA ANDA TIDAK INGIN KE HILANGAN MODUL LAGI!")